document.getElementById("ride").addEventListener("click",checkride);

function checkride() {

 var from = document.getElementById("from").value;
var to = document.getElementById("to").value;
 var pool = document.getElementById("pool").value;
 var direct = document.getElementById("direct").value;
var TotalPrice=0;
var basefare=2.50;
var servicefee=1.75;
var minFare=5.50;
var distanceFare=0;
if (from == "" && to =="")
{
alert("Please input a Value");
  console.log("Need some Input");
}
else if (from == "275 Yorkland Blvd" && to == "CN Tower"){
  distanceFare = (22.9)*(0.81);
  TotalPrice = basefare + servicefee + distanceFare;
  // Count for minimum fare

  if(TotalPrice < minFare){
    TotalPrice = minFare;
  } else {
    TotalPrice = TotalPrice;
  }
  if (pool.checked){
    TotalPrice = TotalPrice;
}else if (direct.checked) {
    TotalPrice = (TotalPrice)* 0.10 + TotalPrice;
}
} else if (from == "Fairview Mall" && to == "Tim Hortons") {
     distanceFare = (1.2)*(0.81);
     TotalPrice = basefare + servicefee + distanceFare;
     if(TotalPrice < minFare){
       TotalPrice = minFare;
     } else {
       TotalPrice = TotalPrice;
     }
     if (pool.checked){
       TotalPrice = TotalPrice;
   }else if (direct.checked) {
       TotalPrice = (TotalPrice)* 0.10 + TotalPrice;
   }
} else {
  alert("Please Enter valid location!");
}

document.getElementById("fareDetails").innerHTML =   "From: " + from + "<br>"
  + "To: " + to + "<br>"
  + "Base Fare: " + basefare + "<br>"
  + "Distance Fare: " + distanceFare + "<br>"
  + "Total Fare: " + TotalPrice  + "<br>"
  ;


}
